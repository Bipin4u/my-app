import './App.css';
import Header from './Header'; 
import Body from './Body';
import About from './About';
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';

import { useState } from 'react';
 


function App() {
  
  const toggle = () =>{
    if(mode==="light"){
      setmode("dark")
      document.body.style.background = '#383838'
    }
    else{
      setmode("light")
      document.body.style.background = 'white'
    }
  }

  const [mode, setmode] = useState("light")
  return (
    <Router>
      <Header textmode = "Textform" mode = {mode} toggle = {toggle}/>
      <Routes>
        <Route path="/home" element ={<Body heading = "Enter text below to analyse." mode = {mode} />}/>
        <Route path="/about" element = {<About mode = {mode} />}/>
      </Routes>
      
    </Router>
  );
}

export default App;
